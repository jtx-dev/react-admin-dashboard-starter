export default function Dashboard() {
    return (
        <div>
            <h2>Dashboard</h2>
            <p>Welcome to your admin dashboard.</p>
        </div>
    );
}
